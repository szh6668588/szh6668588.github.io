// 全局变量
let selectedIssueType = null;
let selectedUrgency = null;
let progressDemoRunning = false;

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    initializeAnimations();
    initializePixiBackground();
    initializeScrollEffects();
});

// 初始化动画效果
function initializeAnimations() {
    // 页面元素淡入动画
    anime({
        targets: '.card-hover',
        translateY: [50, 0],
        opacity: [0, 1],
        delay: anime.stagger(100),
        duration: 800,
        easing: 'easeOutQuart'
    });

    // 标题动画
    anime({
        targets: '.typing-text',
        opacity: [0, 1],
        duration: 1000,
        delay: 500,
        easing: 'easeOutQuart'
    });
}

// 初始化Pixi.js背景效果
function initializePixiBackground() {
    const container = document.getElementById('pixi-container');
    if (!container) return;

    const app = new PIXI.Application({
        width: container.offsetWidth,
        height: container.offsetHeight,
        backgroundColor: 0x1e3a8a,
        backgroundAlpha: 0.1,
        antialias: true
    });

    container.appendChild(app.view);

    // 创建粒子效果
    const particles = [];
    const particleCount = 50;

    for (let i = 0; i < particleCount; i++) {
        const particle = new PIXI.Graphics();
        particle.beginFill(0xffffff, 0.3);
        particle.drawCircle(0, 0, Math.random() * 3 + 1);
        particle.endFill();

        particle.x = Math.random() * app.screen.width;
        particle.y = Math.random() * app.screen.height;
        particle.vx = (Math.random() - 0.5) * 0.5;
        particle.vy = (Math.random() - 0.5) * 0.5;

        app.stage.addChild(particle);
        particles.push(particle);
    }

    // 动画循环
    app.ticker.add(() => {
        particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;

            // 边界检测
            if (particle.x < 0 || particle.x > app.screen.width) {
                particle.vx = -particle.vx;
            }
            if (particle.y < 0 || particle.y > app.screen.height) {
                particle.vy = -particle.vy;
            }
        });
    });

    // 响应式调整
    window.addEventListener('resize', () => {
        app.renderer.resize(container.offsetWidth, container.offsetHeight);
    });
}

// 初始化滚动效果
function initializeScrollEffects() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // 观察需要动画的元素
    document.querySelectorAll('.card-hover, .recommendation-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// 平滑滚动到指定区域
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        const offsetTop = element.offsetTop - 80; // 考虑导航栏高度
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

// 选择问题类型
function selectIssueType(type) {
    selectedIssueType = type;
    
    // 更新按钮状态
    document.querySelectorAll('.issue-type-btn').forEach(btn => {
        btn.classList.remove('border-blue-500', 'bg-blue-50');
        btn.classList.add('border-gray-200');
    });
    
    event.target.closest('.issue-type-btn').classList.remove('border-gray-200');
    event.target.closest('.issue-type-btn').classList.add('border-blue-500', 'bg-blue-50');
    
    // 检查是否可以显示推荐
    checkRecommendation();
    
    // 添加选择动画
    anime({
        targets: event.target.closest('.issue-type-btn'),
        scale: [1, 1.05, 1],
        duration: 300,
        easing: 'easeOutQuart'
    });
}

// 选择紧急程度
function selectUrgency(level) {
    selectedUrgency = level;
    
    // 更新按钮状态
    document.querySelectorAll('.urgency-btn').forEach(btn => {
        btn.classList.remove('border-red-500', 'border-amber-500', 'border-green-500', 'bg-red-50', 'bg-amber-50', 'bg-green-50');
        btn.classList.add('border-gray-200');
    });
    
    const selectedBtn = event.target.closest('.urgency-btn');
    selectedBtn.classList.remove('border-gray-200');
    
    if (level === 'high') {
        selectedBtn.classList.add('border-red-500', 'bg-red-50');
    } else if (level === 'medium') {
        selectedBtn.classList.add('border-amber-500', 'bg-amber-50');
    } else {
        selectedBtn.classList.add('border-green-500', 'bg-green-50');
    }
    
    // 检查是否可以显示推荐
    checkRecommendation();
    
    // 添加选择动画
    anime({
        targets: selectedBtn,
        scale: [1, 1.05, 1],
        duration: 300,
        easing: 'easeOutQuart'
    });
}

// 检查是否显示推荐结果
function checkRecommendation() {
    if (selectedIssueType && selectedUrgency) {
        showRecommendation();
    }
}

// 显示推荐结果
function showRecommendation() {
    const recommendationData = getRecommendationData(selectedIssueType, selectedUrgency);
    const resultDiv = document.getElementById('recommendation-result');
    const contentDiv = document.getElementById('recommendation-content');
    
    contentDiv.innerHTML = `
        <div class="recommendation-card active p-6 rounded-xl mb-4">
            <div class="flex items-start">
                <div class="w-16 h-16 ${recommendationData.color} rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                    ${recommendationData.icon}
                </div>
                <div class="flex-1">
                    <div class="flex items-center mb-2">
                        <h4 class="text-xl font-bold text-gray-900 mr-3">${recommendationData.title}</h4>
                        <span class="px-3 py-1 ${recommendationData.badgeColor} rounded-full text-xs font-medium">
                            推荐
                        </span>
                    </div>
                    <p class="text-gray-600 mb-4">${recommendationData.description}</p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div class="flex items-center">
                            <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                            </svg>
                            <span class="text-gray-600">联系电话：</span>
                            <span class="font-medium">${recommendationData.phone}</span>
                        </div>
                        <div class="flex items-center">
                            <svg class="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                            </svg>
                            <span class="text-gray-600">联系邮箱：</span>
                            <span class="font-medium text-sm">${recommendationData.email}</span>
                        </div>
                    </div>
                    
                    <div class="bg-blue-50 rounded-lg p-4">
                        <h5 class="font-medium text-blue-900 mb-2">推荐理由</h5>
                        <p class="text-blue-800 text-sm">${recommendationData.reason}</p>
                    </div>
                </div>
            </div>
        </div>
        
        ${recommendationData.alternatives.map(alt => `
            <div class="recommendation-card p-4 rounded-xl border border-gray-200 mb-3">
                <div class="flex items-center justify-between">
                    <div>
                        <h5 class="font-medium text-gray-900">${alt.title}</h5>
                        <p class="text-sm text-gray-600">${alt.description}</p>
                    </div>
                    <span class="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                        备选
                    </span>
                </div>
            </div>
        `).join('')}
    `;
    
    resultDiv.style.display = 'block';
    
    // 添加显示动画
    anime({
        targets: resultDiv,
        opacity: [0, 1],
        translateY: [30, 0],
        duration: 600,
        easing: 'easeOutQuart'
    });
    
    // 滚动到结果区域
    setTimeout(() => {
        resultDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 300);
}

// 获取推荐数据
function getRecommendationData(issueType, urgency) {
    const recommendations = {
        holiday: {
            high: {
                title: '衡水市教育局基础教育科',
                description: '最直接的管理与执行部门，负责核定学校校历，对全市中小学的放假、补课安排进行直接审批、监督与违规查处。',
                phone: '0318-2124086',
                email: 'hssjyj@163.com',
                reason: '放假安排问题属于市教育局的直接管辖范围，紧急情况下可直接联系，处理速度最快，效果最好。',
                color: 'bg-blue-100',
                badgeColor: 'bg-blue-100 text-blue-800',
                icon: '<svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>',
                alternatives: [
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门，适合市级未解决问题' },
                    { title: '衡水市12345政务服务便民热线', description: '强制转办渠道，防止部门推诿' }
                ]
            },
            medium: {
                title: '衡水市教育局基础教育科',
                description: '最直接的管理与执行部门，负责核定学校校历，对全市中小学的放假、补课安排进行直接审批、监督与违规查处。',
                phone: '0318-2124086',
                email: 'hssjyj@163.com',
                reason: '放假安排问题属于市教育局的直接管辖范围，建议优先联系，处理效率高。',
                color: 'bg-blue-100',
                badgeColor: 'bg-green-100 text-green-800',
                icon: '<svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>',
                alternatives: [
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门' },
                    { title: '教育部监督举报平台', description: '国家级监督渠道' }
                ]
            },
            low: {
                title: '衡水市教育局基础教育科',
                description: '最直接的管理与执行部门，负责核定学校校历，对全市中小学的放假、补课安排进行直接审批、监督与违规查处。',
                phone: '0318-2124086',
                email: 'hssjyj@163.com',
                reason: '放假安排问题属于市教育局的直接管辖范围，处理流程规范，效果可靠。',
                color: 'bg-blue-100',
                badgeColor: 'bg-blue-100 text-blue-800',
                icon: '<svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>',
                alternatives: [
                    { title: '学校直接反映', description: '先与学校沟通解决' },
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门' }
                ]
            }
        },
        teaching: {
            high: {
                title: '河北省教育厅基础教育处',
                description: '省级业务指导与监督部门，负责制定全省假期政策，对包括衡水学校在内的全省中小学违规办学、占用假期等行为有直接的监督权和处罚权。',
                phone: '0311-66005218',
                email: 'gdyz@mail.hee.gov.cn',
                reason: '教学管理问题涉及多个学校或地区时，省级部门具有更强的协调和处理能力。',
                color: 'bg-purple-100',
                badgeColor: 'bg-red-100 text-red-800',
                icon: '<svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"></path></svg>',
                alternatives: [
                    { title: '衡水市教育局', description: '市级直接管理部门' },
                    { title: '教育部监督举报平台', description: '国家级监督渠道' }
                ]
            },
            medium: {
                title: '衡水市教育局基础教育科',
                description: '最直接的管理与执行部门，负责核定学校校历，对全市中小学的放假、补课安排进行直接审批、监督与违规查处。',
                phone: '0318-2124086',
                email: 'hssjyj@163.com',
                reason: '教学管理问题首先应向市级主管部门反映，处理效率高，协调能力强。',
                color: 'bg-blue-100',
                badgeColor: 'bg-yellow-100 text-yellow-800',
                icon: '<svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>',
                alternatives: [
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门' },
                    { title: '衡水市12345政务服务便民热线', description: '强制转办渠道' }
                ]
            },
            low: {
                title: '衡水市教育局基础教育科',
                description: '最直接的管理与执行部门，负责核定学校校历，对全市中小学的放假、补课安排进行直接审批、监督与违规查处。',
                phone: '0318-2124086',
                email: 'hssjyj@163.com',
                reason: '教学管理问题首先应向市级主管部门反映，处理流程规范，效果可靠。',
                color: 'bg-blue-100',
                badgeColor: 'bg-blue-100 text-blue-800',
                icon: '<svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>',
                alternatives: [
                    { title: '学校直接反映', description: '先与学校沟通解决' },
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门' }
                ]
            }
        },
        inaction: {
            high: {
                title: '衡水市纪委监委',
                description: '针对"不作为"的强力渠道。当市教育局对您的举报不受理、不处理或处理不公时，可向纪委监委举报其"行政不作为"或"履职不力"。',
                phone: '0318-12388',
                email: '河北省纪委监委官网举报平台',
                reason: '部门不作为问题属于纪委监委的监督范围，具有强制力和威慑力。',
                color: 'bg-amber-100',
                badgeColor: 'bg-red-100 text-red-800',
                icon: '<svg class="w-8 h-8 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>',
                alternatives: [
                    { title: '衡水市12345政务服务便民热线', description: '强制转办与督办渠道' },
                    { title: '国务院"互联网+督查"平台', description: '最高级别行政监督' }
                ]
            },
            medium: {
                title: '衡水市12345政务服务便民热线',
                description: '强制性转办与督办渠道。虽非专业部门，但会将投诉形成工单，强制派发给市教育局并限时回复，能有效防止部门推诿。',
                phone: '0318-12345',
                email: '微信小程序"衡水12345"',
                reason: '12345热线具有强制转办功能，能够有效解决部门推诿问题。',
                color: 'bg-green-100',
                badgeColor: 'bg-yellow-100 text-yellow-800',
                icon: '<svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>',
                alternatives: [
                    { title: '衡水市纪委监委', description: '针对不作为的强力监督' },
                    { title: '河北省教育厅基础教育处', description: '上级业务指导部门' }
                ]
            },
            low: {
                title: '河北省教育厅基础教育处',
                description: '省级业务指导与监督部门。负责制定全省假期政策，对包括衡水学校在内的全省中小学违规办学、占用假期等行为有直接的监督权和处罚权。',
                phone: '0311-66005218',
                email: 'gdyz@mail.hee.gov.cn',
                reason: '对于不作为问题，向上级业务主管部门反映是有效的解决途径。',
                color: 'bg-purple-100',
                badgeColor: 'bg-blue-100 text-blue-800',
                icon: '<svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>',
                alternatives: [
                    { title: '衡水市教育局', description: '再次联系市级部门' },
                    { title: '衡水市12345政务服务便民热线', description: '强制转办渠道' }
                ]
            }
        },
        policy: {
            high: {
                title: '国务院"互联网+督查"平台',
                description: '最高级别的行政监督。对地方政府及部门执行国家政策情况进行强力督查，能推动解决因地方保护主义而产生的重大或推诿扯皮问题。',
                phone: '微信搜索"国务院客户端"小程序',
                email: '国务院客户端',
                reason: '国家政策执行问题属于国务院督查范围，具有最高权威性和强制力。',
                color: 'bg-indigo-100',
                badgeColor: 'bg-red-100 text-red-800',
                icon: '<svg class="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>',
                alternatives: [
                    { title: '教育部监督举报平台', description: '国家级教育监督渠道' },
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门' }
                ]
            },
            medium: {
                title: '教育部监督举报平台',
                description: '顶层政策督办渠道。负责确保国家"减负"等宏观政策在地方落实，会对典型性、普遍性的违规问题向省级教育部门进行督办。',
                phone: '12391',
                email: 'http://www.moe.gov.cn/jyb_hygq/hygq_zzjb/',
                reason: '国家政策执行问题应向教育部反映，具有权威性和督办能力。',
                color: 'bg-red-100',
                badgeColor: 'bg-yellow-100 text-yellow-800',
                icon: '<svg class="w-8 h-8 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>',
                alternatives: [
                    { title: '国务院"互联网+督查"平台', description: '最高级别行政监督' },
                    { title: '河北省教育厅基础教育处', description: '省级业务指导部门' }
                ]
            },
            low: {
                title: '河北省教育厅基础教育处',
                description: '省级业务指导与监督部门。负责制定全省假期政策，对包括衡水学校在内的全省中小学违规办学、占用假期等行为有直接的监督权和处罚权。',
                phone: '0311-66005218',
                email: 'gdyz@mail.hee.gov.cn',
                reason: '政策执行问题首先向省级主管部门反映，有利于问题的系统解决。',
                color: 'bg-purple-100',
                badgeColor: 'bg-blue-100 text-blue-800',
                icon: '<svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>',
                alternatives: [
                    { title: '教育部监督举报平台', description: '国家级监督渠道' },
                    { title: '衡水市教育局', description: '市级执行部门' }
                ]
            }
        }
    };
    
    return recommendations[issueType][urgency];
}

// 开始进度演示
function startProgressDemo() {
    if (progressDemoRunning) return;
    
    progressDemoRunning = true;
    const progressLine = document.getElementById('progress-line');
    const steps = document.querySelectorAll('.progress-step');
    
    // 重置所有步骤
    steps.forEach((step, index) => {
        const circle = step.querySelector('.w-16');
        const icon = step.querySelector('svg');
        
        circle.classList.remove('bg-blue-100', 'bg-green-100');
        circle.classList.add('bg-gray-100');
        
        icon.classList.remove('text-blue-600', 'text-green-600');
        icon.classList.add('text-gray-400');
    });
    
    // 重置进度条
    progressLine.style.height = '0%';
    
    // 开始动画
    setTimeout(() => {
        progressLine.style.height = '25%';
        
        setTimeout(() => {
            // 第一步完成
            const step1 = document.querySelector('[data-step="1"] .w-16');
            const icon1 = document.querySelector('[data-step="1"] svg');
            step1.classList.remove('bg-gray-100');
            step1.classList.add('bg-blue-100');
            icon1.classList.remove('text-gray-400');
            icon1.classList.add('text-blue-600');
            
            progressLine.style.height = '50%';
            
            setTimeout(() => {
                // 第二步完成
                const step2 = document.querySelector('[data-step="2"] .w-16');
                const icon2 = document.querySelector('[data-step="2"] svg');
                step2.classList.remove('bg-gray-100');
                step2.classList.add('bg-blue-100');
                icon2.classList.remove('text-gray-400');
                icon2.classList.add('text-blue-600');
                
                progressLine.style.height = '75%';
                
                setTimeout(() => {
                    // 第三步完成
                    const step3 = document.querySelector('[data-step="3"] .w-16');
                    const icon3 = document.querySelector('[data-step="3"] svg');
                    step3.classList.remove('bg-gray-100');
                    step3.classList.add('bg-blue-100');
                    icon3.classList.remove('text-gray-400');
                    icon3.classList.add('text-blue-600');
                    
                    progressLine.style.height = '100%';
                    
                    setTimeout(() => {
                        // 第四步完成
                        const step4 = document.querySelector('[data-step="4"] .w-16');
                        const icon4 = document.querySelector('[data-step="4"] svg');
                        step4.classList.remove('bg-gray-100');
                        step4.classList.add('bg-green-100');
                        icon4.classList.remove('text-gray-400');
                        icon4.classList.add('text-green-600');
                        
                        progressDemoRunning = false;
                    }, 500);
                }, 500);
            }, 500);
        }, 500);
    }, 500);
}

// 处理导航栏滚动效果
window.addEventListener('scroll', function() {
    const nav = document.querySelector('nav');
    if (window.scrollY > 50) {
        nav.classList.add('shadow-lg');
        nav.classList.remove('bg-white/90');
        nav.classList.add('bg-white');
    } else {
        nav.classList.remove('shadow-lg');
        nav.classList.remove('bg-white');
        nav.classList.add('bg-white/90');
    }
});

// 处理移动端菜单切换
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('hidden');
    }
}

// 添加页面加载完成后的动画
document.addEventListener('DOMContentLoaded', function() {
    // 导航栏动画
    anime({
        targets: 'nav',
        translateY: [-100, 0],
        opacity: [0, 1],
        duration: 800,
        easing: 'easeOutQuart'
    });
    
    // 主要内容动画
    anime({
        targets: '.hero-bg .content-overlay',
        translateY: [50, 0],
        opacity: [0, 1],
        duration: 1000,
        delay: 300,
        easing: 'easeOutQuart'
    });
});